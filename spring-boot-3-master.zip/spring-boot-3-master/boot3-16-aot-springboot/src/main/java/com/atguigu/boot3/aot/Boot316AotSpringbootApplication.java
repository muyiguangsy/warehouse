package com.atguigu.boot3.aot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot316AotSpringbootApplication {

    public static void main(String[] args) {
        SpringApplication.run(Boot316AotSpringbootApplication.class, args);
    }

}
