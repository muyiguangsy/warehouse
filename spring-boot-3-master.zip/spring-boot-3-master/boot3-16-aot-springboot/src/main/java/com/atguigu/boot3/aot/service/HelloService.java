package com.atguigu.boot3.aot.service;

import org.springframework.stereotype.Service;

/**
 * @author lfy
 * @Description
 * @create 2023-05-16 11:50
 */
@Service
public class HelloService {


    public String sayHello(){
        return "leifengyang";
    }
}
