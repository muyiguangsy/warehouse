package com.atguigu.boot3.redis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot309RedisApplication {

    public static void main(String[] args) {
        SpringApplication.run(Boot309RedisApplication.class, args);
    }

}
