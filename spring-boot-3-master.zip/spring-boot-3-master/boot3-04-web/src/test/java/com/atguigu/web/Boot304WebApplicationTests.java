package com.atguigu.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot304WebApplicationTests {

    @Test
    void contextLoads() {
    }

}
