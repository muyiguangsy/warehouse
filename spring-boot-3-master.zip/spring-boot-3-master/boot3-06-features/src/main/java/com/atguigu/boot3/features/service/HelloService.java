package com.atguigu.boot3.features.service;

import org.springframework.stereotype.Service;

/**
 * @author lfy
 * @Description
 * @create 2023-04-21 22:12
 */
@Service
public class HelloService {

    public int sum(int a,int b){
        return a+b;
    }
}
