package com.atguigu.boot3.actuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot314ActuatorApplicationTests {

    @Test
    void contextLoads() {
    }

}
