package com.atguigu.boot.bean;

import lombok.Data;

/**
 * @author lfy
 * @Description
 * @create 2023-03-30 9:12
 */
@Data
public class Cat {
    private String name;
    private Integer age;
}
