package com.atguigu.boot3.starter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot308RobotStarterApplicationTests {

    @Test
    void contextLoads() {
    }

}
