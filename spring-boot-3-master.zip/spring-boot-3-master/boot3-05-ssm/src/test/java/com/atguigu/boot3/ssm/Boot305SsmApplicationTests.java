package com.atguigu.boot3.ssm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot305SsmApplicationTests {

    @Test
    void contextLoads() {
    }

}
