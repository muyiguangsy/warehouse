package com.atguigu.boot3.rpc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot311RpcApplicationTests {

    @Test
    void contextLoads() {
    }

}
