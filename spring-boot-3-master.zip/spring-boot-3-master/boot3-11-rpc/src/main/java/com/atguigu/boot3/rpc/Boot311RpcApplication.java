package com.atguigu.boot3.rpc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot311RpcApplication {

    public static void main(String[] args) {
        SpringApplication.run(Boot311RpcApplication.class, args);
    }

}
